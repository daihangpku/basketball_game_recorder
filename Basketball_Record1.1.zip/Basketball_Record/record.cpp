#include "record.h"
#include "record_mode.h"
#include "ui_record.h"
#include<iostream>
#include<QApplication>
#include<QObject>
#include<QVBoxLayout>
#include<Qstring>
#include<QDialog>

Team team1,team2;

record::record(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::record)
{
    ui->setupUi(this);
    record_mode *my = new record_mode;
    my->setGeometry(my->geometry());
    my->show();
    connect(my, SIGNAL(sentdata(Team,Team)), this, SLOT(receivedata(Team,Team)));
}

record::~record()
{
    delete ui;
}

void record::receivedata(Team a,Team b)
{
    team1=a;
    team2=b;
    //cout<<team1.name<<endl<<team2.name<<endl;
    this->show();
}
