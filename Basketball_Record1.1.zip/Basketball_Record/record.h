#ifndef RECORD_H
#define RECORD_H

#include <QWidget>
#include<QDialog>
#include"header.hpp"

namespace Ui {
class record;
}

class record : public QWidget
{
    Q_OBJECT

public:
    explicit record(QWidget *parent = nullptr);
    ~record();

private slots:
    void receivedata(Team a,Team b);

private:
    Ui::record *ui;
};

#endif // RECORD_H
