/********************************************************************************
** Form generated from reading UI file 'replay.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REPLAY_H
#define UI_REPLAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_replay
{
public:
    QPushButton *pushButton;
    QWidget *widget;
    QTextBrowser *textBrowser;
    QPushButton *pushButton_2;
    QWidget *widget_2;
    QLabel *label;
    QPushButton *pushButton_3;

    void setupUi(QWidget *replay)
    {
        if (replay->objectName().isEmpty())
            replay->setObjectName(QString::fromUtf8("replay"));
        replay->resize(1291, 752);
        pushButton = new QPushButton(replay);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(0, 0, 80, 31));
        widget = new QWidget(replay);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(30, 30, 1221, 711));
        textBrowser = new QTextBrowser(widget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(50, 20, 1131, 591));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(560, 640, 111, 41));
        widget_2 = new QWidget(replay);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setGeometry(QRect(10, 19, 1271, 731));
        widget_2->setStyleSheet(QString::fromUtf8("background-color: rgb(85, 255, 255);"));
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(563, 0, 141, 51));
        pushButton_3 = new QPushButton(replay);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(100, 0, 80, 24));

        retranslateUi(replay);

        QMetaObject::connectSlotsByName(replay);
    } // setupUi

    void retranslateUi(QWidget *replay)
    {
        replay->setWindowTitle(QCoreApplication::translate("replay", "Form", nullptr));
        pushButton->setText(QCoreApplication::translate("replay", "\350\277\224\345\233\236", nullptr));
        pushButton_2->setText(QCoreApplication::translate("replay", "\345\257\274\345\207\272", nullptr));
        label->setText(QCoreApplication::translate("replay", "<html><head/><body><p align=\"center\"><span style=\" font-size:20pt;\">\351\200\211\346\213\251\346\257\224\350\265\233</span></p></body></html>", nullptr));
        pushButton_3->setText(QCoreApplication::translate("replay", "PushButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class replay: public Ui_replay {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REPLAY_H
