/****************************************************************************
** Meta object code from reading C++ file 'record.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Basketball_Record/record.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'record.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_record_t {
    const uint offsetsAndSize[148];
    char stringdata0[1517];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_record_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_record_t qt_meta_stringdata_record = {
    {
QT_MOC_LITERAL(0, 6), // "record"
QT_MOC_LITERAL(7, 11), // "receivedata"
QT_MOC_LITERAL(19, 0), // ""
QT_MOC_LITERAL(20, 4), // "Team"
QT_MOC_LITERAL(25, 1), // "a"
QT_MOC_LITERAL(27, 1), // "b"
QT_MOC_LITERAL(29, 4), // "Game"
QT_MOC_LITERAL(34, 1), // "c"
QT_MOC_LITERAL(36, 13), // "timeout1_slot"
QT_MOC_LITERAL(50, 13), // "timeout2_slot"
QT_MOC_LITERAL(64, 15), // "on_get1_clicked"
QT_MOC_LITERAL(80, 15), // "on_get2_clicked"
QT_MOC_LITERAL(96, 15), // "on_get3_clicked"
QT_MOC_LITERAL(112, 15), // "on_foul_clicked"
QT_MOC_LITERAL(128, 18), // "on_timeout_clicked"
QT_MOC_LITERAL(147, 16), // "on_reset_clicked"
QT_MOC_LITERAL(164, 24), // "on_team1_member1_clicked"
QT_MOC_LITERAL(189, 24), // "on_team1_member2_clicked"
QT_MOC_LITERAL(214, 24), // "on_team1_member3_clicked"
QT_MOC_LITERAL(239, 24), // "on_team1_member4_clicked"
QT_MOC_LITERAL(264, 24), // "on_team1_member5_clicked"
QT_MOC_LITERAL(289, 24), // "on_team1_member6_clicked"
QT_MOC_LITERAL(314, 24), // "on_team1_member7_clicked"
QT_MOC_LITERAL(339, 24), // "on_team1_member8_clicked"
QT_MOC_LITERAL(364, 24), // "on_team1_member9_clicked"
QT_MOC_LITERAL(389, 25), // "on_team1_member10_clicked"
QT_MOC_LITERAL(415, 25), // "on_team1_member11_clicked"
QT_MOC_LITERAL(441, 25), // "on_team1_member12_clicked"
QT_MOC_LITERAL(467, 24), // "on_team2_member1_clicked"
QT_MOC_LITERAL(492, 24), // "on_team2_member2_clicked"
QT_MOC_LITERAL(517, 24), // "on_team2_member3_clicked"
QT_MOC_LITERAL(542, 24), // "on_team2_member4_clicked"
QT_MOC_LITERAL(567, 24), // "on_team2_member5_clicked"
QT_MOC_LITERAL(592, 24), // "on_team2_member6_clicked"
QT_MOC_LITERAL(617, 24), // "on_team2_member7_clicked"
QT_MOC_LITERAL(642, 24), // "on_team2_member8_clicked"
QT_MOC_LITERAL(667, 24), // "on_team2_member9_clicked"
QT_MOC_LITERAL(692, 25), // "on_team2_member10_clicked"
QT_MOC_LITERAL(718, 25), // "on_team2_member11_clicked"
QT_MOC_LITERAL(744, 25), // "on_team2_member12_clicked"
QT_MOC_LITERAL(770, 24), // "on_timeout_team1_clicked"
QT_MOC_LITERAL(795, 24), // "on_timeout_team2_clicked"
QT_MOC_LITERAL(820, 23), // "on_next_quarter_clicked"
QT_MOC_LITERAL(844, 22), // "on_foul_player_clicked"
QT_MOC_LITERAL(867, 21), // "on_foul_coach_clicked"
QT_MOC_LITERAL(889, 19), // "on_player_P_clicked"
QT_MOC_LITERAL(909, 19), // "on_player_T_clicked"
QT_MOC_LITERAL(929, 19), // "on_player_U_clicked"
QT_MOC_LITERAL(949, 12), // "on_D_clicked"
QT_MOC_LITERAL(962, 18), // "on_coach_B_clicked"
QT_MOC_LITERAL(981, 18), // "on_coach_C_clicked"
QT_MOC_LITERAL(1000, 17), // "on_foul_0_clicked"
QT_MOC_LITERAL(1018, 17), // "on_foul_1_clicked"
QT_MOC_LITERAL(1036, 17), // "on_foul_2_clicked"
QT_MOC_LITERAL(1054, 17), // "on_foul_3_clicked"
QT_MOC_LITERAL(1072, 28), // "on_will_next_quarter_clicked"
QT_MOC_LITERAL(1101, 27), // "on_not_next_quarter_clicked"
QT_MOC_LITERAL(1129, 22), // "on_team1_coach_clicked"
QT_MOC_LITERAL(1152, 22), // "on_team2_coach_clicked"
QT_MOC_LITERAL(1175, 16), // "on_begin_clicked"
QT_MOC_LITERAL(1192, 25), // "on_bigtime_freeze_clicked"
QT_MOC_LITERAL(1218, 27), // "on_bigtime_continue_clicked"
QT_MOC_LITERAL(1246, 27), // "on_smalltime_freeze_clicked"
QT_MOC_LITERAL(1274, 29), // "on_smalltime_continue_clicked"
QT_MOC_LITERAL(1304, 23), // "on_bigtime_plus_clicked"
QT_MOC_LITERAL(1328, 27), // "on_bigtime_subtract_clicked"
QT_MOC_LITERAL(1356, 25), // "on_smalltime_plus_clicked"
QT_MOC_LITERAL(1382, 29), // "on_smalltime_subtract_clicked"
QT_MOC_LITERAL(1412, 26), // "on_smalltime_reset_clicked"
QT_MOC_LITERAL(1439, 21), // "on_end_record_clicked"
QT_MOC_LITERAL(1461, 22), // "on_comfirm_end_clicked"
QT_MOC_LITERAL(1484, 18), // "on_not_end_clicked"
QT_MOC_LITERAL(1503, 9), // "saveevent"
QT_MOC_LITERAL(1513, 3) // "str"

    },
    "record\0receivedata\0\0Team\0a\0b\0Game\0c\0"
    "timeout1_slot\0timeout2_slot\0on_get1_clicked\0"
    "on_get2_clicked\0on_get3_clicked\0"
    "on_foul_clicked\0on_timeout_clicked\0"
    "on_reset_clicked\0on_team1_member1_clicked\0"
    "on_team1_member2_clicked\0"
    "on_team1_member3_clicked\0"
    "on_team1_member4_clicked\0"
    "on_team1_member5_clicked\0"
    "on_team1_member6_clicked\0"
    "on_team1_member7_clicked\0"
    "on_team1_member8_clicked\0"
    "on_team1_member9_clicked\0"
    "on_team1_member10_clicked\0"
    "on_team1_member11_clicked\0"
    "on_team1_member12_clicked\0"
    "on_team2_member1_clicked\0"
    "on_team2_member2_clicked\0"
    "on_team2_member3_clicked\0"
    "on_team2_member4_clicked\0"
    "on_team2_member5_clicked\0"
    "on_team2_member6_clicked\0"
    "on_team2_member7_clicked\0"
    "on_team2_member8_clicked\0"
    "on_team2_member9_clicked\0"
    "on_team2_member10_clicked\0"
    "on_team2_member11_clicked\0"
    "on_team2_member12_clicked\0"
    "on_timeout_team1_clicked\0"
    "on_timeout_team2_clicked\0"
    "on_next_quarter_clicked\0on_foul_player_clicked\0"
    "on_foul_coach_clicked\0on_player_P_clicked\0"
    "on_player_T_clicked\0on_player_U_clicked\0"
    "on_D_clicked\0on_coach_B_clicked\0"
    "on_coach_C_clicked\0on_foul_0_clicked\0"
    "on_foul_1_clicked\0on_foul_2_clicked\0"
    "on_foul_3_clicked\0on_will_next_quarter_clicked\0"
    "on_not_next_quarter_clicked\0"
    "on_team1_coach_clicked\0on_team2_coach_clicked\0"
    "on_begin_clicked\0on_bigtime_freeze_clicked\0"
    "on_bigtime_continue_clicked\0"
    "on_smalltime_freeze_clicked\0"
    "on_smalltime_continue_clicked\0"
    "on_bigtime_plus_clicked\0"
    "on_bigtime_subtract_clicked\0"
    "on_smalltime_plus_clicked\0"
    "on_smalltime_subtract_clicked\0"
    "on_smalltime_reset_clicked\0"
    "on_end_record_clicked\0on_comfirm_end_clicked\0"
    "on_not_end_clicked\0saveevent\0str"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_record[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      66,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    3,  410,    2, 0x08,    1 /* Private */,
       8,    0,  417,    2, 0x08,    5 /* Private */,
       9,    0,  418,    2, 0x08,    6 /* Private */,
      10,    0,  419,    2, 0x08,    7 /* Private */,
      11,    0,  420,    2, 0x08,    8 /* Private */,
      12,    0,  421,    2, 0x08,    9 /* Private */,
      13,    0,  422,    2, 0x08,   10 /* Private */,
      14,    0,  423,    2, 0x08,   11 /* Private */,
      15,    0,  424,    2, 0x08,   12 /* Private */,
      16,    0,  425,    2, 0x08,   13 /* Private */,
      17,    0,  426,    2, 0x08,   14 /* Private */,
      18,    0,  427,    2, 0x08,   15 /* Private */,
      19,    0,  428,    2, 0x08,   16 /* Private */,
      20,    0,  429,    2, 0x08,   17 /* Private */,
      21,    0,  430,    2, 0x08,   18 /* Private */,
      22,    0,  431,    2, 0x08,   19 /* Private */,
      23,    0,  432,    2, 0x08,   20 /* Private */,
      24,    0,  433,    2, 0x08,   21 /* Private */,
      25,    0,  434,    2, 0x08,   22 /* Private */,
      26,    0,  435,    2, 0x08,   23 /* Private */,
      27,    0,  436,    2, 0x08,   24 /* Private */,
      28,    0,  437,    2, 0x08,   25 /* Private */,
      29,    0,  438,    2, 0x08,   26 /* Private */,
      30,    0,  439,    2, 0x08,   27 /* Private */,
      31,    0,  440,    2, 0x08,   28 /* Private */,
      32,    0,  441,    2, 0x08,   29 /* Private */,
      33,    0,  442,    2, 0x08,   30 /* Private */,
      34,    0,  443,    2, 0x08,   31 /* Private */,
      35,    0,  444,    2, 0x08,   32 /* Private */,
      36,    0,  445,    2, 0x08,   33 /* Private */,
      37,    0,  446,    2, 0x08,   34 /* Private */,
      38,    0,  447,    2, 0x08,   35 /* Private */,
      39,    0,  448,    2, 0x08,   36 /* Private */,
      40,    0,  449,    2, 0x08,   37 /* Private */,
      41,    0,  450,    2, 0x08,   38 /* Private */,
      42,    0,  451,    2, 0x08,   39 /* Private */,
      43,    0,  452,    2, 0x08,   40 /* Private */,
      44,    0,  453,    2, 0x08,   41 /* Private */,
      45,    0,  454,    2, 0x08,   42 /* Private */,
      46,    0,  455,    2, 0x08,   43 /* Private */,
      47,    0,  456,    2, 0x08,   44 /* Private */,
      48,    0,  457,    2, 0x08,   45 /* Private */,
      49,    0,  458,    2, 0x08,   46 /* Private */,
      50,    0,  459,    2, 0x08,   47 /* Private */,
      51,    0,  460,    2, 0x08,   48 /* Private */,
      52,    0,  461,    2, 0x08,   49 /* Private */,
      53,    0,  462,    2, 0x08,   50 /* Private */,
      54,    0,  463,    2, 0x08,   51 /* Private */,
      55,    0,  464,    2, 0x08,   52 /* Private */,
      56,    0,  465,    2, 0x08,   53 /* Private */,
      57,    0,  466,    2, 0x08,   54 /* Private */,
      58,    0,  467,    2, 0x08,   55 /* Private */,
      59,    0,  468,    2, 0x08,   56 /* Private */,
      60,    0,  469,    2, 0x08,   57 /* Private */,
      61,    0,  470,    2, 0x08,   58 /* Private */,
      62,    0,  471,    2, 0x08,   59 /* Private */,
      63,    0,  472,    2, 0x08,   60 /* Private */,
      64,    0,  473,    2, 0x08,   61 /* Private */,
      65,    0,  474,    2, 0x08,   62 /* Private */,
      66,    0,  475,    2, 0x08,   63 /* Private */,
      67,    0,  476,    2, 0x08,   64 /* Private */,
      68,    0,  477,    2, 0x08,   65 /* Private */,
      69,    0,  478,    2, 0x08,   66 /* Private */,
      70,    0,  479,    2, 0x08,   67 /* Private */,
      71,    0,  480,    2, 0x08,   68 /* Private */,
      72,    1,  481,    2, 0x08,   69 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3, 0x80000000 | 6,    4,    5,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   73,

       0        // eod
};

void record::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<record *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->receivedata((*reinterpret_cast< std::add_pointer_t<Team>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Team>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<Game>>(_a[3]))); break;
        case 1: _t->timeout1_slot(); break;
        case 2: _t->timeout2_slot(); break;
        case 3: _t->on_get1_clicked(); break;
        case 4: _t->on_get2_clicked(); break;
        case 5: _t->on_get3_clicked(); break;
        case 6: _t->on_foul_clicked(); break;
        case 7: _t->on_timeout_clicked(); break;
        case 8: _t->on_reset_clicked(); break;
        case 9: _t->on_team1_member1_clicked(); break;
        case 10: _t->on_team1_member2_clicked(); break;
        case 11: _t->on_team1_member3_clicked(); break;
        case 12: _t->on_team1_member4_clicked(); break;
        case 13: _t->on_team1_member5_clicked(); break;
        case 14: _t->on_team1_member6_clicked(); break;
        case 15: _t->on_team1_member7_clicked(); break;
        case 16: _t->on_team1_member8_clicked(); break;
        case 17: _t->on_team1_member9_clicked(); break;
        case 18: _t->on_team1_member10_clicked(); break;
        case 19: _t->on_team1_member11_clicked(); break;
        case 20: _t->on_team1_member12_clicked(); break;
        case 21: _t->on_team2_member1_clicked(); break;
        case 22: _t->on_team2_member2_clicked(); break;
        case 23: _t->on_team2_member3_clicked(); break;
        case 24: _t->on_team2_member4_clicked(); break;
        case 25: _t->on_team2_member5_clicked(); break;
        case 26: _t->on_team2_member6_clicked(); break;
        case 27: _t->on_team2_member7_clicked(); break;
        case 28: _t->on_team2_member8_clicked(); break;
        case 29: _t->on_team2_member9_clicked(); break;
        case 30: _t->on_team2_member10_clicked(); break;
        case 31: _t->on_team2_member11_clicked(); break;
        case 32: _t->on_team2_member12_clicked(); break;
        case 33: _t->on_timeout_team1_clicked(); break;
        case 34: _t->on_timeout_team2_clicked(); break;
        case 35: _t->on_next_quarter_clicked(); break;
        case 36: _t->on_foul_player_clicked(); break;
        case 37: _t->on_foul_coach_clicked(); break;
        case 38: _t->on_player_P_clicked(); break;
        case 39: _t->on_player_T_clicked(); break;
        case 40: _t->on_player_U_clicked(); break;
        case 41: _t->on_D_clicked(); break;
        case 42: _t->on_coach_B_clicked(); break;
        case 43: _t->on_coach_C_clicked(); break;
        case 44: _t->on_foul_0_clicked(); break;
        case 45: _t->on_foul_1_clicked(); break;
        case 46: _t->on_foul_2_clicked(); break;
        case 47: _t->on_foul_3_clicked(); break;
        case 48: _t->on_will_next_quarter_clicked(); break;
        case 49: _t->on_not_next_quarter_clicked(); break;
        case 50: _t->on_team1_coach_clicked(); break;
        case 51: _t->on_team2_coach_clicked(); break;
        case 52: _t->on_begin_clicked(); break;
        case 53: _t->on_bigtime_freeze_clicked(); break;
        case 54: _t->on_bigtime_continue_clicked(); break;
        case 55: _t->on_smalltime_freeze_clicked(); break;
        case 56: _t->on_smalltime_continue_clicked(); break;
        case 57: _t->on_bigtime_plus_clicked(); break;
        case 58: _t->on_bigtime_subtract_clicked(); break;
        case 59: _t->on_smalltime_plus_clicked(); break;
        case 60: _t->on_smalltime_subtract_clicked(); break;
        case 61: _t->on_smalltime_reset_clicked(); break;
        case 62: _t->on_end_record_clicked(); break;
        case 63: _t->on_comfirm_end_clicked(); break;
        case 64: _t->on_not_end_clicked(); break;
        case 65: _t->saveevent((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject record::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_record.offsetsAndSize,
    qt_meta_data_record,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_record_t
, QtPrivate::TypeAndForceComplete<record, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Team, std::false_type>, QtPrivate::TypeAndForceComplete<Team, std::false_type>, QtPrivate::TypeAndForceComplete<Game, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>


>,
    nullptr
} };


const QMetaObject *record::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *record::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_record.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int record::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 66)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 66;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 66)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 66;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
