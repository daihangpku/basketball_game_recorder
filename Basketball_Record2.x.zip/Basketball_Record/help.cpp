#include "help.h"
#include "ui_help.h"
#include "mainwindow.h"

help::help(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::help)
{
    ui->setupUi(this);
    this->move(150,80);
    setWindowTitle("帮助");
}

help::~help()
{
    delete ui;
}

void help::on_pushButton_clicked()
{
    MainWindow *me = new MainWindow;
    me->setGeometry(me->geometry());
    me->show();
    this->close();
}

