#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"record_mode.h"
#include<iostream>
#include<QApplication>
using namespace std;
int x=1;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //ui->pushButton->setStyleSheet("QPushButton{font-size:32px;}");
    //ui->pushButton_2->setStyleSheet("QPushButton{font-size:32px;}");
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    record_mode *my = new record_mode;
    my->setGeometry(my->geometry());
    my->show();
    this->close();
}

