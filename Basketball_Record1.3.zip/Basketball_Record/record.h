#ifndef RECORD_H
#define RECORD_H

#include <QWidget>
#include<QDialog>
#include"header.hpp"

namespace Ui {
class record;
}

class record : public QWidget
{
    Q_OBJECT

public:
    explicit record(QWidget *parent = nullptr);
    ~record();

private slots:
    void receivedata(Team a,Team b);

    void on_get1_clicked();

    void on_get2_clicked();

    void on_get3_clicked();

    void on_foul_clicked();

    void on_timeout_clicked();

    void on_reset_clicked();

    void on_team1_member1_clicked();

    void on_team1_member2_clicked();

    void on_team1_member3_clicked();

    void on_team1_member4_clicked();

    void on_team1_member5_clicked();

    void on_team1_member6_clicked();

    void on_team1_member7_clicked();

    void on_team1_member8_clicked();

    void on_team1_member9_clicked();

    void on_team1_member10_clicked();

    void on_team1_member11_clicked();

    void on_team1_member12_clicked();

    void on_team2_member1_clicked();

    void on_team2_member2_clicked();

    void on_team2_member3_clicked();

    void on_team2_member4_clicked();

    void on_team2_member5_clicked();

    void on_team2_member6_clicked();

    void on_team2_member7_clicked();

    void on_team2_member8_clicked();

    void on_team2_member9_clicked();

    void on_team2_member10_clicked();

    void on_team2_member11_clicked();

    void on_team2_member12_clicked();

    void on_timeout_team1_clicked();

    void on_timeout_team2_clicked();

    void on_next_quarter_clicked();

    void on_foul_player_clicked();

    void on_foul_coach_clicked();

    void on_player_P_clicked();

    void on_player_T_clicked();

    void on_player_U_clicked();

    void on_D_clicked();

    void on_coach_B_clicked();

    void on_coach_C_clicked();

    void on_foul_0_clicked();

    void on_foul_1_clicked();

    void on_foul_2_clicked();

    void on_foul_3_clicked();

    void on_will_next_quarter_clicked();

    void on_not_next_quarter_clicked();

    void on_team1_coach_clicked();

    void on_team2_coach_clicked();

private:
    Ui::record *ui;
};

#endif // RECORD_H
