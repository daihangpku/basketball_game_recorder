/****************************************************************************
** Meta object code from reading C++ file 'record.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Basketball_Record/record.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'record.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_record_t {
    const uint offsetsAndSize[110];
    char stringdata0[1140];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_record_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_record_t qt_meta_stringdata_record = {
    {
QT_MOC_LITERAL(0, 6), // "record"
QT_MOC_LITERAL(7, 11), // "receivedata"
QT_MOC_LITERAL(19, 0), // ""
QT_MOC_LITERAL(20, 4), // "Team"
QT_MOC_LITERAL(25, 1), // "a"
QT_MOC_LITERAL(27, 1), // "b"
QT_MOC_LITERAL(29, 15), // "on_get1_clicked"
QT_MOC_LITERAL(45, 15), // "on_get2_clicked"
QT_MOC_LITERAL(61, 15), // "on_get3_clicked"
QT_MOC_LITERAL(77, 15), // "on_foul_clicked"
QT_MOC_LITERAL(93, 18), // "on_timeout_clicked"
QT_MOC_LITERAL(112, 16), // "on_reset_clicked"
QT_MOC_LITERAL(129, 24), // "on_team1_member1_clicked"
QT_MOC_LITERAL(154, 24), // "on_team1_member2_clicked"
QT_MOC_LITERAL(179, 24), // "on_team1_member3_clicked"
QT_MOC_LITERAL(204, 24), // "on_team1_member4_clicked"
QT_MOC_LITERAL(229, 24), // "on_team1_member5_clicked"
QT_MOC_LITERAL(254, 24), // "on_team1_member6_clicked"
QT_MOC_LITERAL(279, 24), // "on_team1_member7_clicked"
QT_MOC_LITERAL(304, 24), // "on_team1_member8_clicked"
QT_MOC_LITERAL(329, 24), // "on_team1_member9_clicked"
QT_MOC_LITERAL(354, 25), // "on_team1_member10_clicked"
QT_MOC_LITERAL(380, 25), // "on_team1_member11_clicked"
QT_MOC_LITERAL(406, 25), // "on_team1_member12_clicked"
QT_MOC_LITERAL(432, 24), // "on_team2_member1_clicked"
QT_MOC_LITERAL(457, 24), // "on_team2_member2_clicked"
QT_MOC_LITERAL(482, 24), // "on_team2_member3_clicked"
QT_MOC_LITERAL(507, 24), // "on_team2_member4_clicked"
QT_MOC_LITERAL(532, 24), // "on_team2_member5_clicked"
QT_MOC_LITERAL(557, 24), // "on_team2_member6_clicked"
QT_MOC_LITERAL(582, 24), // "on_team2_member7_clicked"
QT_MOC_LITERAL(607, 24), // "on_team2_member8_clicked"
QT_MOC_LITERAL(632, 24), // "on_team2_member9_clicked"
QT_MOC_LITERAL(657, 25), // "on_team2_member10_clicked"
QT_MOC_LITERAL(683, 25), // "on_team2_member11_clicked"
QT_MOC_LITERAL(709, 25), // "on_team2_member12_clicked"
QT_MOC_LITERAL(735, 24), // "on_timeout_team1_clicked"
QT_MOC_LITERAL(760, 24), // "on_timeout_team2_clicked"
QT_MOC_LITERAL(785, 23), // "on_next_quarter_clicked"
QT_MOC_LITERAL(809, 22), // "on_foul_player_clicked"
QT_MOC_LITERAL(832, 21), // "on_foul_coach_clicked"
QT_MOC_LITERAL(854, 19), // "on_player_P_clicked"
QT_MOC_LITERAL(874, 19), // "on_player_T_clicked"
QT_MOC_LITERAL(894, 19), // "on_player_U_clicked"
QT_MOC_LITERAL(914, 12), // "on_D_clicked"
QT_MOC_LITERAL(927, 18), // "on_coach_B_clicked"
QT_MOC_LITERAL(946, 18), // "on_coach_C_clicked"
QT_MOC_LITERAL(965, 17), // "on_foul_0_clicked"
QT_MOC_LITERAL(983, 17), // "on_foul_1_clicked"
QT_MOC_LITERAL(1001, 17), // "on_foul_2_clicked"
QT_MOC_LITERAL(1019, 17), // "on_foul_3_clicked"
QT_MOC_LITERAL(1037, 28), // "on_will_next_quarter_clicked"
QT_MOC_LITERAL(1066, 27), // "on_not_next_quarter_clicked"
QT_MOC_LITERAL(1094, 22), // "on_team1_coach_clicked"
QT_MOC_LITERAL(1117, 22) // "on_team2_coach_clicked"

    },
    "record\0receivedata\0\0Team\0a\0b\0"
    "on_get1_clicked\0on_get2_clicked\0"
    "on_get3_clicked\0on_foul_clicked\0"
    "on_timeout_clicked\0on_reset_clicked\0"
    "on_team1_member1_clicked\0"
    "on_team1_member2_clicked\0"
    "on_team1_member3_clicked\0"
    "on_team1_member4_clicked\0"
    "on_team1_member5_clicked\0"
    "on_team1_member6_clicked\0"
    "on_team1_member7_clicked\0"
    "on_team1_member8_clicked\0"
    "on_team1_member9_clicked\0"
    "on_team1_member10_clicked\0"
    "on_team1_member11_clicked\0"
    "on_team1_member12_clicked\0"
    "on_team2_member1_clicked\0"
    "on_team2_member2_clicked\0"
    "on_team2_member3_clicked\0"
    "on_team2_member4_clicked\0"
    "on_team2_member5_clicked\0"
    "on_team2_member6_clicked\0"
    "on_team2_member7_clicked\0"
    "on_team2_member8_clicked\0"
    "on_team2_member9_clicked\0"
    "on_team2_member10_clicked\0"
    "on_team2_member11_clicked\0"
    "on_team2_member12_clicked\0"
    "on_timeout_team1_clicked\0"
    "on_timeout_team2_clicked\0"
    "on_next_quarter_clicked\0on_foul_player_clicked\0"
    "on_foul_coach_clicked\0on_player_P_clicked\0"
    "on_player_T_clicked\0on_player_U_clicked\0"
    "on_D_clicked\0on_coach_B_clicked\0"
    "on_coach_C_clicked\0on_foul_0_clicked\0"
    "on_foul_1_clicked\0on_foul_2_clicked\0"
    "on_foul_3_clicked\0on_will_next_quarter_clicked\0"
    "on_not_next_quarter_clicked\0"
    "on_team1_coach_clicked\0on_team2_coach_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_record[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      50,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,  314,    2, 0x08,    1 /* Private */,
       6,    0,  319,    2, 0x08,    4 /* Private */,
       7,    0,  320,    2, 0x08,    5 /* Private */,
       8,    0,  321,    2, 0x08,    6 /* Private */,
       9,    0,  322,    2, 0x08,    7 /* Private */,
      10,    0,  323,    2, 0x08,    8 /* Private */,
      11,    0,  324,    2, 0x08,    9 /* Private */,
      12,    0,  325,    2, 0x08,   10 /* Private */,
      13,    0,  326,    2, 0x08,   11 /* Private */,
      14,    0,  327,    2, 0x08,   12 /* Private */,
      15,    0,  328,    2, 0x08,   13 /* Private */,
      16,    0,  329,    2, 0x08,   14 /* Private */,
      17,    0,  330,    2, 0x08,   15 /* Private */,
      18,    0,  331,    2, 0x08,   16 /* Private */,
      19,    0,  332,    2, 0x08,   17 /* Private */,
      20,    0,  333,    2, 0x08,   18 /* Private */,
      21,    0,  334,    2, 0x08,   19 /* Private */,
      22,    0,  335,    2, 0x08,   20 /* Private */,
      23,    0,  336,    2, 0x08,   21 /* Private */,
      24,    0,  337,    2, 0x08,   22 /* Private */,
      25,    0,  338,    2, 0x08,   23 /* Private */,
      26,    0,  339,    2, 0x08,   24 /* Private */,
      27,    0,  340,    2, 0x08,   25 /* Private */,
      28,    0,  341,    2, 0x08,   26 /* Private */,
      29,    0,  342,    2, 0x08,   27 /* Private */,
      30,    0,  343,    2, 0x08,   28 /* Private */,
      31,    0,  344,    2, 0x08,   29 /* Private */,
      32,    0,  345,    2, 0x08,   30 /* Private */,
      33,    0,  346,    2, 0x08,   31 /* Private */,
      34,    0,  347,    2, 0x08,   32 /* Private */,
      35,    0,  348,    2, 0x08,   33 /* Private */,
      36,    0,  349,    2, 0x08,   34 /* Private */,
      37,    0,  350,    2, 0x08,   35 /* Private */,
      38,    0,  351,    2, 0x08,   36 /* Private */,
      39,    0,  352,    2, 0x08,   37 /* Private */,
      40,    0,  353,    2, 0x08,   38 /* Private */,
      41,    0,  354,    2, 0x08,   39 /* Private */,
      42,    0,  355,    2, 0x08,   40 /* Private */,
      43,    0,  356,    2, 0x08,   41 /* Private */,
      44,    0,  357,    2, 0x08,   42 /* Private */,
      45,    0,  358,    2, 0x08,   43 /* Private */,
      46,    0,  359,    2, 0x08,   44 /* Private */,
      47,    0,  360,    2, 0x08,   45 /* Private */,
      48,    0,  361,    2, 0x08,   46 /* Private */,
      49,    0,  362,    2, 0x08,   47 /* Private */,
      50,    0,  363,    2, 0x08,   48 /* Private */,
      51,    0,  364,    2, 0x08,   49 /* Private */,
      52,    0,  365,    2, 0x08,   50 /* Private */,
      53,    0,  366,    2, 0x08,   51 /* Private */,
      54,    0,  367,    2, 0x08,   52 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3,    4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void record::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<record *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->receivedata((*reinterpret_cast< std::add_pointer_t<Team>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Team>>(_a[2]))); break;
        case 1: _t->on_get1_clicked(); break;
        case 2: _t->on_get2_clicked(); break;
        case 3: _t->on_get3_clicked(); break;
        case 4: _t->on_foul_clicked(); break;
        case 5: _t->on_timeout_clicked(); break;
        case 6: _t->on_reset_clicked(); break;
        case 7: _t->on_team1_member1_clicked(); break;
        case 8: _t->on_team1_member2_clicked(); break;
        case 9: _t->on_team1_member3_clicked(); break;
        case 10: _t->on_team1_member4_clicked(); break;
        case 11: _t->on_team1_member5_clicked(); break;
        case 12: _t->on_team1_member6_clicked(); break;
        case 13: _t->on_team1_member7_clicked(); break;
        case 14: _t->on_team1_member8_clicked(); break;
        case 15: _t->on_team1_member9_clicked(); break;
        case 16: _t->on_team1_member10_clicked(); break;
        case 17: _t->on_team1_member11_clicked(); break;
        case 18: _t->on_team1_member12_clicked(); break;
        case 19: _t->on_team2_member1_clicked(); break;
        case 20: _t->on_team2_member2_clicked(); break;
        case 21: _t->on_team2_member3_clicked(); break;
        case 22: _t->on_team2_member4_clicked(); break;
        case 23: _t->on_team2_member5_clicked(); break;
        case 24: _t->on_team2_member6_clicked(); break;
        case 25: _t->on_team2_member7_clicked(); break;
        case 26: _t->on_team2_member8_clicked(); break;
        case 27: _t->on_team2_member9_clicked(); break;
        case 28: _t->on_team2_member10_clicked(); break;
        case 29: _t->on_team2_member11_clicked(); break;
        case 30: _t->on_team2_member12_clicked(); break;
        case 31: _t->on_timeout_team1_clicked(); break;
        case 32: _t->on_timeout_team2_clicked(); break;
        case 33: _t->on_next_quarter_clicked(); break;
        case 34: _t->on_foul_player_clicked(); break;
        case 35: _t->on_foul_coach_clicked(); break;
        case 36: _t->on_player_P_clicked(); break;
        case 37: _t->on_player_T_clicked(); break;
        case 38: _t->on_player_U_clicked(); break;
        case 39: _t->on_D_clicked(); break;
        case 40: _t->on_coach_B_clicked(); break;
        case 41: _t->on_coach_C_clicked(); break;
        case 42: _t->on_foul_0_clicked(); break;
        case 43: _t->on_foul_1_clicked(); break;
        case 44: _t->on_foul_2_clicked(); break;
        case 45: _t->on_foul_3_clicked(); break;
        case 46: _t->on_will_next_quarter_clicked(); break;
        case 47: _t->on_not_next_quarter_clicked(); break;
        case 48: _t->on_team1_coach_clicked(); break;
        case 49: _t->on_team2_coach_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject record::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_record.offsetsAndSize,
    qt_meta_data_record,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_record_t
, QtPrivate::TypeAndForceComplete<record, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Team, std::false_type>, QtPrivate::TypeAndForceComplete<Team, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *record::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *record::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_record.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int record::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 50)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 50;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 50)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 50;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
