#include "record.h"
#include "record_mode.h"
#include "ui_record.h"
#include<iostream>
#include<QApplication>
#include<QObject>
#include<QVBoxLayout>
#include<Qstring>
#include<QDialog>

Team team1,team2;

record::record(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::record)
{
    ui->setupUi(this);
    record_mode *my = new record_mode;
    my->setGeometry(my->geometry());
    my->show();
    connect(my, SIGNAL(sentdata(Team,Team)), this, SLOT(receivedata(Team,Team)));
    ui->team1_widget->setSelectionMode(QAbstractItemView::NoSelection);
    ui->team2_widget->setSelectionMode(QAbstractItemView::NoSelection);
    ui->team1_widget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->team2_widget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->teama_total->setSelectionMode(QAbstractItemView::NoSelection);
    ui->teama_total->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->teamb_total->setSelectionMode(QAbstractItemView::NoSelection);
    ui->teamb_total->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->timeout_team1->hide();
    ui->timeout_team2->hide();
}

record::~record()
{
    delete ui;
}

void record::receivedata(Team a,Team b)
{
    team1=a;
    team2=b;
    this->show();
}

void record::on_get1_clicked()
{

}

void record::on_get2_clicked()
{

}

void record::on_get3_clicked()
{

}

void record::on_foul_clicked()
{

}

void record::on_timeout_clicked()
{

}

void record::on_timeout_team1_clicked()
{

}

void record::on_timeout_team2_clicked()
{

}

void record::on_reset_clicked()
{

}

void record::on_team1_member1_clicked()
{

}

void record::on_team1_member2_clicked()
{

}

void record::on_team1_member3_clicked()
{

}

void record::on_team1_member4_clicked()
{

}

void record::on_team1_member5_clicked()
{

}

void record::on_team1_member6_clicked()
{

}

void record::on_team1_member7_clicked()
{

}

void record::on_team1_member8_clicked()
{

}

void record::on_team1_member9_clicked()
{

}

void record::on_team1_member10_clicked()
{

}

void record::on_team1_member11_clicked()
{

}

void record::on_team1_member12_clicked()
{

}

void record::on_team2_member1_clicked()
{

}

void record::on_team2_member2_clicked()
{

}

void record::on_team2_member3_clicked()
{

}

void record::on_team2_member4_clicked()
{

}

void record::on_team2_member5_clicked()
{

}

void record::on_team2_member6_clicked()
{

}

void record::on_team2_member7_clicked()
{

}

void record::on_team2_member8_clicked()
{

}

void record::on_team2_member9_clicked()
{

}

void record::on_team2_member10_clicked()
{

}

void record::on_team2_member11_clicked()
{

}

void record::on_team2_member12_clicked()
{

}

void record::on_next_quarter_clicked()
{

}
