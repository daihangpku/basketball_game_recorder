#include "record.h"
#include "record_mode.h"
#include "ui_record.h"
#include<iostream>
#include<QApplication>
#include<QObject>
#include<QVBoxLayout>
#include<Qstring>
#include<QDialog>
#include<vector>
Event* EVENT[10000];
int event_num=0;
Team team1,team2;
int GET=0;
int current_time;
int quarter;//1~4
bool FOUL=0;

record::record(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::record)
{
    ui->setupUi(this);
    record_mode *my = new record_mode;
    my->setGeometry(my->geometry());
    my->show();
    connect(my, SIGNAL(sentdata(Team,Team)), this, SLOT(receivedata(Team,Team)));
    ui->team1_widget->setSelectionMode(QAbstractItemView::NoSelection);
    ui->team2_widget->setSelectionMode(QAbstractItemView::NoSelection);
    ui->team1_widget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->team2_widget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->teama_total->setSelectionMode(QAbstractItemView::NoSelection);
    ui->teama_total->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->teamb_total->setSelectionMode(QAbstractItemView::NoSelection);
    ui->teamb_total->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->timeout_team1->hide();
    ui->timeout_team2->hide();
}

record::~record()
{
    delete ui;
}

void record::receivedata(Team a,Team b)
{
    team1=a;
    team2=b;
    this->show();
}

void record::on_get1_clicked()
{
    GET=1;

    FOUL=false;
}

void record::on_get2_clicked()
{
    GET=2;

    FOUL=false;
}

void record::on_get3_clicked()
{
    GET=3;
    FOUL=false;
}

void record::on_foul_clicked()
{
    GET=0;
    FOUL=true;
}

void record::on_timeout_clicked()
{

}

void record::on_timeout_team1_clicked()
{

}

void record::on_timeout_team2_clicked()
{

}

void record::on_reset_clicked()
{
    GET=0;
    FOUL=false;
}

void record::on_team1_member1_clicked()
{
    if(GET){
        team1.get_score(team1.players[0], GET,current_time,quarter);
        EVENT[event_num]=new Score_event("score",pair(current_time,quarter),1,0,GET);
    }
    else if(FOUL==1){


        team1.get_foul(team1.players[0], int 罚则,char 类型,current_time,quarter);
        EVENT[event_num]=new Foul_event("foul",pair(current_time,quarter),1,0,Foul());
    }
}

void record::on_team1_member2_clicked()
{

}

void record::on_team1_member3_clicked()
{

}

void record::on_team1_member4_clicked()
{

}

void record::on_team1_member5_clicked()
{

}

void record::on_team1_member6_clicked()
{

}

void record::on_team1_member7_clicked()
{

}

void record::on_team1_member8_clicked()
{

}

void record::on_team1_member9_clicked()
{

}

void record::on_team1_member10_clicked()
{

}

void record::on_team1_member11_clicked()
{

}

void record::on_team1_member12_clicked()
{

}

void record::on_team2_member1_clicked()
{

}

void record::on_team2_member2_clicked()
{

}

void record::on_team2_member3_clicked()
{

}

void record::on_team2_member4_clicked()
{

}

void record::on_team2_member5_clicked()
{

}

void record::on_team2_member6_clicked()
{

}

void record::on_team2_member7_clicked()
{

}

void record::on_team2_member8_clicked()
{

}

void record::on_team2_member9_clicked()
{

}

void record::on_team2_member10_clicked()
{

}

void record::on_team2_member11_clicked()
{

}

void record::on_team2_member12_clicked()
{

}

void record::on_next_quarter_clicked()
{

}
