/****************************************************************************
** Meta object code from reading C++ file 'replay.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Basketball_Record/replay.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'replay.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_replay_t {
    const uint offsetsAndSize[38];
    char stringdata0[226];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_replay_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_replay_t qt_meta_stringdata_replay = {
    {
QT_MOC_LITERAL(0, 6), // "replay"
QT_MOC_LITERAL(7, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(29, 0), // ""
QT_MOC_LITERAL(30, 13), // "timeout1_slot"
QT_MOC_LITERAL(44, 20), // "generate_game_report"
QT_MOC_LITERAL(65, 5), // "Game&"
QT_MOC_LITERAL(71, 4), // "game"
QT_MOC_LITERAL(76, 5), // "Team&"
QT_MOC_LITERAL(82, 5), // "team1"
QT_MOC_LITERAL(88, 5), // "team2"
QT_MOC_LITERAL(94, 14), // "on_see_clicked"
QT_MOC_LITERAL(109, 15), // "on_out1_clicked"
QT_MOC_LITERAL(125, 19), // "on_all_show_clicked"
QT_MOC_LITERAL(145, 21), // "on_continue_2_clicked"
QT_MOC_LITERAL(167, 15), // "on_stop_clicked"
QT_MOC_LITERAL(183, 15), // "on_out2_clicked"
QT_MOC_LITERAL(199, 13), // "process_event"
QT_MOC_LITERAL(213, 6), // "Event*"
QT_MOC_LITERAL(220, 5) // "event"

    },
    "replay\0on_pushButton_clicked\0\0"
    "timeout1_slot\0generate_game_report\0"
    "Game&\0game\0Team&\0team1\0team2\0"
    "on_see_clicked\0on_out1_clicked\0"
    "on_all_show_clicked\0on_continue_2_clicked\0"
    "on_stop_clicked\0on_out2_clicked\0"
    "process_event\0Event*\0event"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_replay[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   74,    2, 0x08,    1 /* Private */,
       3,    0,   75,    2, 0x08,    2 /* Private */,
       4,    3,   76,    2, 0x08,    3 /* Private */,
      10,    0,   83,    2, 0x08,    7 /* Private */,
      11,    0,   84,    2, 0x08,    8 /* Private */,
      12,    0,   85,    2, 0x08,    9 /* Private */,
      13,    0,   86,    2, 0x08,   10 /* Private */,
      14,    0,   87,    2, 0x08,   11 /* Private */,
      15,    0,   88,    2, 0x08,   12 /* Private */,
      16,    3,   89,    2, 0x08,   13 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5, 0x80000000 | 7, 0x80000000 | 7,    6,    8,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 7, 0x80000000 | 7, 0x80000000 | 17,    8,    9,   18,

       0        // eod
};

void replay::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<replay *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_pushButton_clicked(); break;
        case 1: _t->timeout1_slot(); break;
        case 2: _t->generate_game_report((*reinterpret_cast< std::add_pointer_t<Game&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Team&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<Team&>>(_a[3]))); break;
        case 3: _t->on_see_clicked(); break;
        case 4: _t->on_out1_clicked(); break;
        case 5: _t->on_all_show_clicked(); break;
        case 6: _t->on_continue_2_clicked(); break;
        case 7: _t->on_stop_clicked(); break;
        case 8: _t->on_out2_clicked(); break;
        case 9: _t->process_event((*reinterpret_cast< std::add_pointer_t<Team&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Team&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<Event*>>(_a[3]))); break;
        default: ;
        }
    }
}

const QMetaObject replay::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_replay.offsetsAndSize,
    qt_meta_data_replay,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_replay_t
, QtPrivate::TypeAndForceComplete<replay, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Game &, std::false_type>, QtPrivate::TypeAndForceComplete<Team &, std::false_type>, QtPrivate::TypeAndForceComplete<Team &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<Team &, std::false_type>, QtPrivate::TypeAndForceComplete<Team &, std::false_type>, QtPrivate::TypeAndForceComplete<Event *, std::false_type>


>,
    nullptr
} };


const QMetaObject *replay::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *replay::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_replay.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int replay::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
