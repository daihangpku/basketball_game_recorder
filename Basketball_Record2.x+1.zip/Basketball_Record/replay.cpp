#include "replay.h"
#include "ui_replay.h"
#include "mainwindow.h"
#include "header.hpp"
#include<iostream>
#include<QTime>
#include<QTimer>

int num_events;
int now_report_event=0;
string filename="aa";
vector<Event*> events;
Team teamx,teamy;

QString string_to_qstring2(const string& str)
{
    return QString(QString::fromLocal8Bit(str));
}

string qstring_to_string2(const QString& qstr)
{
    QByteArray localBytes = qstr.toLocal8Bit();
    return localBytes.data();
}

Game input_game(ifstream& fin) {
    string game_name,game_info,team1,team2;
    fin>>game_name>>game_info;
    fin>>team1>>team2;
    Game tmp(game_name,team1,team2,game_info);
    return tmp;
}

Team input_team(ifstream& fin,bool is_first_team){
    string name;
    int num_of_player;
    fin>>name>>num_of_player;
    Player* players[12];
    for(int i=0;i<num_of_player;i++){
        string pname,num;
        fin>>pname>>num;
        players[i]=new Player(pname,num);
    }
    string hname;
    fin>>hname;
    Headcoach* headcoach=new Headcoach(hname);
    Team t(name,is_first_team,players,num_of_player,headcoach);
    return t;
}

Event *input_event(ifstream& fin){
    string event_type;
    int event_time1,event_time2;
    fin>>event_type;
    fin>>event_time1>>event_time2;
    if(event_type=="score"){
        int players_team;
        int player_num_in_list;
        int pts;
        fin>>players_team>>player_num_in_list>>pts;
        return new Score_event(event_type,make_pair(event_time1,event_time2),players_team,player_num_in_list,pts);
    }
    else if(event_type=="foul"){
        int players_team;
        int player_num_in_list;
        Foul foul;
        fin>>players_team>>player_num_in_list;
        fin>>foul.penalty>>foul.type>>foul.time;
        return new Foul_event(event_type,make_pair(event_time1,event_time2),players_team,player_num_in_list,foul);
    }
    else if(event_type=="timeout"){
        int team;
        fin>>team;
        return new Timeout_event(event_type,make_pair(event_time1,event_time2),team);
    }
}

replay::replay(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::replay)
{
    ui->setupUi(this);
    this->move(150,80);
    setWindowTitle("篮球记录系统");
    ui->widget->hide();
    connect(&timer1,SIGNAL(timeout()),this,SLOT(timeout1_slot()));
    time1.setHMS(0,0,0,0);
}

replay::~replay()
{
    delete ui;
}

void replay::timeout1_slot()
{
    if(now_report_event<num_events){
        //print event[now...]
        now_report_event++;
    }
    else{
        timer1.stop();
        ui->stop->hide();
        ui->continue_2->hide();
        ui->all_show->hide();
    }
}

void replay::on_pushButton_clicked()
{
    MainWindow *me = new MainWindow;
    me->setGeometry(me->geometry());
    me->show();
    this->close();
}

void replay::generate_game_report(Game &game, Team &team1, Team &team2) {
    //fout << "Game Report: " << game.game_name << endl;
    ui->screen->append("Game Report: "+string_to_qstring2(game.game_name)+"\n");
    //fout << game.game_info << endl;
    ui->screen->append(string_to_qstring2(game.game_info)+"\n");
    //fout << "Teams: " << game.team1 << " vs " << game.team2 << endl;
    ui->screen->append("Teams: "+string_to_qstring2(game.team1+"vs"+game.team2)+"\n");

    // Print team details
    //fout << "Team 1: " << team1.name << endl;
    ui->screen->append("Team 1:"+string_to_qstring2(team1.name)+"\n");
    for (int i = 0; i < team1.num_of_player; ++i) {
        //fout << "Player: " << team1.players[i]->name << " (Number: " << team1.players[i]->num << ")" << endl;
        ui->screen->append("Player: "+string_to_qstring2(team1.players[i]->name+" (Number: "+team1.players[i]->num+")")+"\n");
        //fout << "Total Score: " << team1.players[i]->total_score << ", Total Fouls: " << team1.players[i]->total_foul << endl;
        ui->screen->append("Total Score: "+QString::number(team1.players[i]->total_score)+", Total Fouls: "+QString::number(team1.players[i]->total_foul)+"\n");
    }
    //fout << "Head Coach: " << team1.head_coach->name << endl;
    ui->screen->append("Head Coach: "+string_to_qstring2(team1.head_coach->name)+"\n");
    //fout << "Total Team Score: " << team1.total_team_score << endl;
    ui->screen->append("Total Team Score: "+QString::number(team1.total_team_score)+"\n");

    //cout << "Team 2: " << team2.name << endl;
    ui->screen->append("Team 2:"+string_to_qstring2(team2.name)+"\n");
    for (int i = 0; i < team2.num_of_player; ++i) {
        //fout << "Player: " << team2.players[i]->name << " (Number: " << team2.players[i]->num << ")" << endl;
        ui->screen->append("Player: "+string_to_qstring2(team2.players[i]->name+" (Number: "+team2.players[i]->num+")")+"\n");
        //fout << "Total Score: " << team2.players[i]->total_score << ", Total Fouls: " << team2.players[i]->total_foul << endl;
        ui->screen->append("Total Score: "+QString::number(team2.players[i]->total_score)+", Total Fouls: "+QString::number(team2.players[i]->total_foul)+"\n");
    }
    //fout << "Head Coach: " << team2.head_coach->name << endl;
    ui->screen->append("Head Coach: "+string_to_qstring2(team2.head_coach->name)+"\n");
    //fout << "Total Team Score: " << team2.total_team_score << endl;
    ui->screen->append("Total Team Score: "+QString::number(team2.total_team_score)+"\n");

    ui->screen->append(QString::number(num_events));

}

void replay::process_event(Team &team1, Team &team2, Event* event) {
    if (Score_event* score_event = dynamic_cast<Score_event*>(event)) {
        // 处理得分事件
        Team &team = (score_event->players_team == 1) ? team1 : team2;
        team.get_score(team.players[score_event->player_num_in_list], score_event->pts, score_event->event_time.first, score_event->event_time.second);
    } else if (Foul_event* foul_event = dynamic_cast<Foul_event*>(event)) {
        // 处理犯规事件
        Team &team = (foul_event->players_team == 1) ? team1 : team2;
        team.get_foul(team.players[foul_event->player_num_in_list], foul_event->foul.penalty, foul_event->foul.type, foul_event->foul.time, foul_event->event_time.second);
    } else if (Timeout_event* timeout_event = dynamic_cast<Timeout_event*>(event)) {
        // 处理暂停事件
        Team &team = (timeout_event->team == 1) ? team1 : team2;
        team.get_timeout(timeout_event->event_time.first, timeout_event->event_time.second);
    }
}

void replay::on_see_clicked()
{
    ui->widget->show();
    ui->widget_2->hide();
    ui->continue_2->hide();
    ifstream fin("Savedgames//"+filename+".txt"); // 打开输入文件
    //ofstream fout("Savedgames//bb.txt");
    // Input game information
    Game game = input_game(fin);
    // Input team information
    teamx = Team(input_team(fin,true));
    teamy = Team(input_team(fin,false));
    // Input events
    fin >> num_events;
    for (int i = 0; i < num_events; ++i) {
        events.push_back(input_event(fin));
    }
    for (Event* event : events) {
        process_event(teamx, teamy, event);
    }
    // Generate the game report
    generate_game_report(game, teamx, teamy);
    timer1.start(20);
    // Clean up dynamically allocated memory
    //for (Event* event : events) {
    //    delete event;
    //}
}

void replay::on_all_show_clicked()
{
    //for...
    timer1.stop();
    ui->stop->hide();
    ui->continue_2->hide();
    ui->all_show->hide();
}

void replay::on_continue_2_clicked()
{
    ui->continue_2->hide();
    ui->stop->show();
    timer1.start(20);
}

void replay::on_stop_clicked()
{
    ui->continue_2->show();
    ui->stop->hide();
    timer1.stop();
}

void replay::on_out1_clicked()
{

}

void replay::on_out2_clicked()
{

}
